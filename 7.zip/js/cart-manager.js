// Make addItemToCart available globally
window.addItemToCart = addItemToCart

document.addEventListener("DOMContentLoaded", () => {
  updateCartCount()
})

function addItemToCart(product) {
  const cart = JSON.parse(localStorage.getItem("cart")) || []

  // Check if the product is already in the cart
  const existingItem = cart.find((item) => item.id === product.id)

  if (existingItem) {
    // Increase quantity if already in cart
    existingItem.quantity += 1
  } else {
    // Add new item to cart
    cart.push({
      id: product.id,
      title: product.title,
      image: product.image,
      price: product.price,
      quantity: 1,
    })
  }

  // Save cart to localStorage
  localStorage.setItem("cart", JSON.stringify(cart))

  // Update cart count
  updateCartCount()

  // Show notification
  showNotification(`${product.title} added to cart`)
}

function removeFromCart(id) {
  const cart = JSON.parse(localStorage.getItem("cart")) || []
  const updatedCart = cart.filter((item) => item.id !== id)
  localStorage.setItem("cart", JSON.stringify(updatedCart))
  updateCartCount()
}

function updateQuantity(id, delta) {
  const cart = JSON.parse(localStorage.getItem("cart")) || []
  const item = cart.find((item) => item.id === id)

  if (item) {
    item.quantity += delta

    if (item.quantity <= 0) {
      removeFromCart(id)
      return
    }

    localStorage.setItem("cart", JSON.stringify(cart))
    updateCartCount()
  }
}

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem("cart")) || []
  const totalCount = cart.reduce((acc, item) => acc + (item.quantity || 0), 0)
  const cartCountElement = document.getElementById("cart-count")

  if (cartCountElement) {
    cartCountElement.textContent = totalCount
  }
}

function showNotification(message) {
  // Remove any existing notification
  const existingNotification = document.querySelector(".cart-notification")
  if (existingNotification) {
    document.body.removeChild(existingNotification)
  }

  // Create notification element
  const notification = document.createElement("div")
  notification.className = "cart-notification"
  notification.textContent = message
  notification.style.position = "fixed"
  notification.style.top = "20px"
  notification.style.right = "20px"
  notification.style.backgroundColor = "var(--color-black)"
  notification.style.color = "var(--color-white)"
  notification.style.padding = "15px 20px"
  notification.style.zIndex = "1000"
  notification.style.opacity = "0"
  notification.style.transform = "translateY(-10px)"
  notification.style.transition = "all 0.3s ease"

  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.style.opacity = "1"
    notification.style.transform = "translateY(0)"
  }, 100)

  // Hide notification after 3 seconds
  setTimeout(() => {
    notification.style.opacity = "0"
    notification.style.transform = "translateY(-10px)"

    setTimeout(() => {
      if (notification.parentNode) {
        document.body.removeChild(notification)
      }
    }, 300)
  }, 3000)
}

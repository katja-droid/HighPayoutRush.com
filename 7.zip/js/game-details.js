document.addEventListener("DOMContentLoaded", () => {
  const gameDetailsContainer = document.getElementById("game-details-container")

  if (!gameDetailsContainer) return

  // Get game ID from URL
  const urlParams = new URLSearchParams(window.location.search)
  const gameId = Number.parseInt(urlParams.get("id"))

  if (!gameId) {
    gameDetailsContainer.innerHTML = "<p>Game not found</p>"
    return
  }

  fetch("./data/games.json")
    .then((response) => response.json())
    .then((data) => {
      const game = data.games.find((g) => g.id === gameId)

      if (!game) {
        gameDetailsContainer.innerHTML = "<p>Game not found</p>"
        return
      }

      // Update page title
      document.title = `${game.title} - DigitalGamingHub`

      gameDetailsContainer.innerHTML = `
        <div class="game-image-large">
          <img src="${game.image}" alt="${game.title}">
        </div>
        <div class="game-info-large">
          <h1 class="game-title-large">${game.title}</h1>
          <div class="game-price-large">$${game.price.toFixed(2)}</div>
          
          <p>${game.description}</p>
          
        
          </div>
          
          <button class="btn btn-primary add-to-cart-btn" data-id="${game.id}">Add to Cart</button>
        </div>
      `

      // Add event listener to the Add to Cart button
      const addToCartBtn = gameDetailsContainer.querySelector(".add-to-cart-btn")
      addToCartBtn.addEventListener("click", () => {
        addToCart(game)
      })
    })
    .catch((error) => console.error("Error loading game details:", error))
})

function addToCart(game) {
  if (window.addItemToCart) {
    window.addItemToCart(game)
  } else {
    console.error("Cart manager not loaded")
  }
}

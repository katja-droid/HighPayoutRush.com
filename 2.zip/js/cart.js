import { updateCartCount } from "./cart-count.js"

// First, let's fix the addToCart function to handle different product structures
export function addToCart(product) {
  const cart = JSON.parse(localStorage.getItem("cart")) || []

  // Check if the product is already in the cart
  const existingItem = cart.find((item) => item.id === product.id)

  if (existingItem) {
    // Increase quantity if already in cart
    existingItem.quantity += 1
  } else {
    // Normalize the product object to ensure consistent structure
    cart.push({
      id: product.id,
      title: product.title,
      // Handle different image property names (image or photo)
      image: product.image || product.photo,
      price: Number(product.price),
      quantity: 1,
    })
  }

  // Save cart to localStorage
  localStorage.setItem("cart", JSON.stringify(cart))

  // Update cart count
  updateCartCount()

  // Show notification
  showNotification(`${product.title} added to cart`)
}

export function removeFromCart(id) {
  const cart = JSON.parse(localStorage.getItem("cart")) || []

  // Remove item from cart
  const updatedCart = cart.filter((item) => item.id !== id)

  // Save updated cart to localStorage
  localStorage.setItem("cart", JSON.stringify(updatedCart))

  // Update cart count
  updateCartCount()

  // Render cart items if we're on the cart page
  if (document.getElementById("cart-list")) {
    renderCartItems()
  }
}

export function updateQuantity(id, delta) {
  const cart = JSON.parse(localStorage.getItem("cart")) || []

  // Find the item in the cart
  const item = cart.find((item) => item.id === id)

  if (item) {
    // Update quantity
    item.quantity += delta

    // Remove item if quantity is 0 or less
    if (item.quantity <= 0) {
      removeFromCart(id)
      return
    }

    // Save updated cart to localStorage
    localStorage.setItem("cart", JSON.stringify(cart))

    // Update cart count
    updateCartCount()

    // Render cart items if we're on the cart page
    if (document.getElementById("cart-list")) {
      renderCartItems()
    }
  }
}

// Fix the renderCartItems function to handle edge cases
export function renderCartItems() {
  const cartList = document.getElementById("cart-list")
  const emptyCartMessage = document.getElementById("empty-cart-message")
  const cartSummary = document.getElementById("cart-summary")

  if (!cartList) return

  const cart = JSON.parse(localStorage.getItem("cart")) || []

  // Clear cart list
  cartList.innerHTML = ""

  if (cart.length === 0) {
    // Show empty cart message
    if (emptyCartMessage) emptyCartMessage.style.display = "block"
    if (cartSummary) cartSummary.style.display = "none"
    return
  }

  // Hide empty cart message
  if (emptyCartMessage) emptyCartMessage.style.display = "none"
  if (cartSummary) cartSummary.style.display = "block"

  // Calculate totals
  let subtotal = 0
  let itemCount = 0

  // Render cart items
  cart.forEach((item) => {
    const itemTotal = item.price * item.quantity
    subtotal += itemTotal
    itemCount += item.quantity

    const cartItem = document.createElement("li")
    cartItem.className = "cart-item"

    cartItem.innerHTML = `
      <img src="${item.image}" alt="${item.title}" class="cart-img">
      <div class="cart-wrapper">
        <h3 class="cart-title">${item.title}</h3>
        <div class="cart-price">$${Number(item.price).toFixed(2)}</div>
        <div class="cart-controls">
          <button class="decrease-btn" data-id="${item.id}">-</button>
          <span class="quantity">${item.quantity}</span>
          <button class="increase-btn" data-id="${item.id}">+</button>
          <button class="remove-btn" data-id="${item.id}">Remove</button>
        </div>
      </div>
    `

    cartList.appendChild(cartItem)

    // Add event listeners
    const decreaseBtn = cartItem.querySelector(".decrease-btn")
    const increaseBtn = cartItem.querySelector(".increase-btn")
    const removeBtn = cartItem.querySelector(".remove-btn")

    decreaseBtn.addEventListener("click", () => {
      updateQuantity(item.id, -1)
    })

    increaseBtn.addEventListener("click", () => {
      updateQuantity(item.id, 1)
    })

    removeBtn.addEventListener("click", () => {
      removeFromCart(item.id)
    })
  })

  // Update summary
  const itemCountEl = document.getElementById("item-count")
  const subtotalEl = document.getElementById("summary-subtotal")
  const discountEl = document.getElementById("summary-discount")
  const totalEl = document.getElementById("summary-total")

  if (itemCountEl) itemCountEl.textContent = itemCount
  if (subtotalEl) subtotalEl.textContent = `$${subtotal.toFixed(2)}`
  if (discountEl) discountEl.textContent = "$0.00"
  if (totalEl) totalEl.textContent = `$${subtotal.toFixed(2)}`
}

// Fix the showNotification function to ensure it's visible
function showNotification(message) {
  // Check if notification already exists and remove it
  const existingNotification = document.querySelector(".cart-notification")
  if (existingNotification) {
    document.body.removeChild(existingNotification)
  }

  // Create notification element
  const notification = document.createElement("div")
  notification.className = "cart-notification"
  notification.textContent = message
  notification.style.position = "fixed"
  notification.style.top = "20px"
  notification.style.right = "20px"
  notification.style.backgroundColor = "var(--primary-color)"
  notification.style.color = "var(--text-color)"
  notification.style.padding = "15px 20px"
  notification.style.borderRadius = "4px"
  notification.style.zIndex = "1000"
  notification.style.boxShadow = "0 5px 15px rgba(0, 0, 0, 0.3)"
  notification.style.opacity = "0"
  notification.style.transform = "translateY(-10px)"
  notification.style.transition = "all 0.3s ease"

  // Add notification to document
  document.body.appendChild(notification)

  // Show notification
  setTimeout(() => {
    notification.style.opacity = "1"
    notification.style.transform = "translateY(0)"
  }, 100)

  // Hide and remove notification after 3 seconds
  setTimeout(() => {
    notification.style.opacity = "0"
    notification.style.transform = "translateY(-10px)"
    setTimeout(() => {
      if (notification.parentNode) {
        document.body.removeChild(notification)
      }
    }, 300)
  }, 3000)
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("cart-list")) {
    renderCartItems()
  }
  updateCartCount()
})
